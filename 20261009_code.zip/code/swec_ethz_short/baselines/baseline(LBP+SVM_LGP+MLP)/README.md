## PYTHON files description
* **`iEEGFunctions.py`**: This file contains the function for all the scripts. Inside there is a class *HD_classifier*, with all the functions for training and testing with HD. Furthermore, you can find 4 functions for different future extractions used for the other two classifier, SVM and MLP.
* **`iEEGClassifierMLP+1-DLGP.py`**: almost similar to the previous script, with a different classifier;
* **`iEEGClassifierSVM+LBP.py`**: same consideration of above script;
* **`MLP_PostProcessing.py`**: the only difference with previous script is the name of the file and the type of the data inside (numpy and not torch). Moreover, instead of a list, you can set a single variable to choose the patient, iPatient.
* **`SVM_PostProcessing.py`**: same consideration of above script;


