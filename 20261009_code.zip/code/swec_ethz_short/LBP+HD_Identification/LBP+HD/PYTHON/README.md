## PYTHON files description
* **`iEEGFunctions.py`**: This file contains the function for all the scripts. Inside there is a class *HD_classifier*, with all the functions for training and testing with HD. Furthermore, you can find 4 functions for different future extractions used for other classifier, like SVM and MLP in this specific case.
* **`iEEGClassifierLBP+HD.py`**: it contains all the informations to run the test: you have to set the index of the GPU (*device*) and the set of Patient to test (*PatientList*); there are also other paramethers to change if you want, like the dimension of the HV or the type of itemMemory.
* **`iEEGClassifierMLP+1-DLGP.py`**: almost similar to the previous script, with a different classifier;
* **`iEEGClassifierSVM+LBP.py`**: same consideration of above script;
* **`HD_PostProcessing.py`**: Here you do the postprocessing patient per patient using the output files of previous scripts. A variable, iPatient, let you decide the patient that you want to postprocess. Is very fast to execute (< 10 second).
* **`MLP_PostProcessing.py`**: the only difference with previous script is the name of the file and the type of the data inside (numpy and not torch).
* **`SVM_PostProcessing.py`**: same consideration of above script;


