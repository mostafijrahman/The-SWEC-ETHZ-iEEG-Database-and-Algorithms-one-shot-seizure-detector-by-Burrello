close all
clear all
pat = 15;
loadstring = sprintf ('C:/Users/ale_m/OneDrive/Desktop/RevisionTBME_analysis/Pat%d_rankChannels.mat',pat);
load(loadstring);
if pat == 9
    rankChannels = rankChannels(:,[1:2 4:7],:);
end
nelectrodes =[100 64 62 42 59 36 74 61 92 47 59 54 98 49 56 64];
nchannels = size(rankChannels,3);
nSeiz = [5 4 14 4 6 2 7 3 6 13 2 10 2 10 9 2];
%nSeizures = 1;
nSeizures =nSeiz(pat);
q = 1:1:nchannels;
%right channels
%query = q<57;    %Pat1
%query = (q>12 & q<25) | (q>32 & q<41) | (q>46 & q<53) | (q>58 & q<65);
% query = only left;
% query = only left;
%query = q>30;
% query = q<25;
% query = only left;
% query = q<11 | (q>20 & q<25) | (q>30 & q<37) | (q>42 & q<49) | (q>54 & q<58);
% query = q<49;
% query = only left;
% query = q<15;
% query = q<43;
% query = q<76;
% query = only left;
 query = q>48;
%query = q<11 | (q>20 & q<27) | (q>32 & q<39) | (q>44 & q<51) | (q>56 & q<61);
query0 = (query - 1) < 0;
for i = 1:length(query)
    if query(i) == 1
        labels(i,:) = 'right hemi-sphere';
    else
        labels(i,:) = 'left  hemi-sphere';
    end
end
%for intNumber = 1:5
    %rankCh=reshape(rankChannels(intNumber,1:nSeizures,:),[nSeizures,nchannels]);
    rankCh=reshape(rankChannels(:,1:nSeizures,:),[nSeizures*5,nchannels]);
    RightBrain = [];
    LeftBrain = [];
    rankChannelsVariance = [];
    labelsused = [];
    for i = 1:nSeizures*5
        RightBrain = [RightBrain rankCh(i,query) ];
        LeftBrain = [LeftBrain rankCh(i,query0)];
        rankChannelsVariance = [ rankChannelsVariance; rankCh(i,:)'];
        labelsused = [labelsused; labels];
    end
    % [h,p] = kstest(rankChannelsVariance)
    % vartestn(rankChannelsVariance  , labelsused ); %%pvalue --> lower means that the variance are different so I have to use unequal
    %figure(intNumber)
    figure(1)
    h=boxplot(rankChannelsVariance  , labelsused ,'Widths',0.5,'BoxStyle','outline','Colors',[0 0 0; 0 176/255 240/255],'MedianStyle','line','Symbol','*');
    %h=boxplot(rankChannelsVariance ,'Widths',0.5,'BoxStyle','compact','Colors',[0 0 0; 0 176/255 240/255],'MedianStyle','line','Symbol','*')
    x0=200;
    y0=200;
    width=250;
    height=200;
    set(gcf,'units','points','position',[x0,y0,width,height])
    disp('t-student test');
    [h,p] = ttest2(RightBrain, LeftBrain, 'Alpha', 0.001, 'Vartype', 'equal'); %pvalue --> low it means that the means are different 
    fprintf ("Mean Right: %f, Mean Left: %f, p-value: %.5f\n",mean(RightBrain), mean(LeftBrain),p);
    Confidence = (1-p)*100;
%end

%% HeatMap
loadstring = sprintf ('C:/Users/ale_m/OneDrive/Desktop/ETH_files/Seizure_dataset/Pat%d/Sz1.mat',pat);
load(loadstring);
figure('rend','painters','pos',[10 10 1200 150]);
%cdata1=reshape(rankCh([query; query; query; query; query; query; query; query; query; query]),10,32);
%cdata2=reshape(rankCh([query0; query0; query0; query0; query0; query0; query0; query0; query0; query0]),10,32);
%cdata = [cdata2 cdata1];
xvalues = channelNameArray';
yvalues = {'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45'};%,'Seiz. 3','Seiz. 4'};
h = heatmap(xvalues,yvalues,rankCh);
h.Title = 'HD score';
h.XLabel = 'number of Electrodes';
h.YLabel = 'Series';
