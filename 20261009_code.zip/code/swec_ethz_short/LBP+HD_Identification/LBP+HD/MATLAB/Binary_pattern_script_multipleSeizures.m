%   Binary_pattern_script_multipleSeizures.m
%   Alessio Burrello
%   Last modification: 27-04-2018

%   Test of Seizures with individual Training Seizure, using LBP as
%   preprocessing

%   Approach:
%   1. Identification of the part of ictal period to train the algorithm
%   and global variables definition
%   2. Create the 2 different item memory.
%   3. Create prototypes from all the seizures: I will have n/2 Ictal and
%   n/2 interictal prototypes, because I use 2 seizures in every group.
%   4. Test each individual seizure using all the groups, one at a time. In
%   practice I test all seizures using two seizure to train, rotating
%   this group over all the available ones.
%   5. Prediction for every single time-sample: we save that data in a
%   folder names binary_data
%   6.Post-processing applied in a different script


clear all;
close all;
clc;

%% 1.
tbeginict(1,:) =  [184 184 183 186 186 0   0   0   0   0 0 0 0 0];
tendict(1,:) =    [192 193 189 190 200 0   0   0   0   0 0 0 0 0];
tbeginict(2,:) =  [180 192 188 186 0   0   0   0   0   0 0 0 0 0];
tendict(2,:) =    [210 215 215 215 0   0   0   0   0   0 0 0 0 0];
tbeginict(4,:) =  [220 219 200 192 0   0   0   0   0   0 0 0 0 0];
tendict(4,:) =    [250 255 239 217 0   0   0   0   0   0 0 0 0 0];
tbeginict(5,:) =  [187 188 208 202 202 212 0   0   0   0 0 0 0 0];
tendict(5,:) =    [225 218 234 231 221 242 0   0   0   0 0 0 0 0];
tbeginict(6,:) =  [184 186 0   0   0   0   0   0   0   0 0 0 0 0];
tendict(6,:) =    [193 195 0   0   0   0   0   0   0   0 0 0 0 0];
tbeginict(8,:) =  [185 188 185 0   0   0   0   0   0   0 0 0 0 0];
tendict(8,:) =    [205 205 210 0   0   0   0   0   0   0 0 0 0 0];
tbeginict(9,:) =  [188 204 204 214 183 203 185 0   0   0 0 0 0 0];
tendict(9,:) =    [201 231 217 244 195 226 211 0   0   0 0 0 0 0];
tbeginict(11,:) = [181 180 0   0   0   0   0   0   0   0 0 0 0 0];
tendict(11,:) =   [211 210 0   0   0   0   0   0   0   0 0 0 0 0];
tbeginict(13,:) = [185 185 0   0   0   0   0   0   0   0 0 0 0 0];
tendict(13,:) =   [210 210 0   0   0   0   0   0   0   0 0 0 0 0];
tbeginict(14,:) = [195 230 194 195 184 185 235 185 182 185 0 0 0 0];
tendict(14,:) =   [210 247 218 219 214 220 268 220 222 222 0 0 0 0];
tbeginict(15,:) = [213 208 200 204 210 200 216 205 203 0 0 0 0 0];
tendict(15,:) =   [238 225 225 234 235 225 241 225 233 0 0 0 0 0];
tbeginict(16,:) = [205 195 0   0   0   0   0   0   0   0 0 0 0 0];
tendict(16,:) =   [235 225 0   0   0   0   0   0   0   0 0 0 0 0];

%declare global variables to use in functions
global IDxHV
global D
global IDbpHV 
global T
global dT

seizureN = [5 4 14 4 6 2 7 3 7 13 2 10 2 10 9 2];   %number of seizures of every patient
fs = 512;               %frequency of the signal
T = 7;                  %total of the points + 1 of the LBP code
dT = 1;                 %advancing in time of the LBP code
nPatients = 16;         %total number of patients in dataset
totalNumberBP = 2^(T-1);%total number of symbols
D = 10000;              % dimension of hypervector
LBP_functions;          %here there are all the functions that we use


%%  Define patient and time period of (first) seizure to learn "queery vector" from. 

%List of patient that we want to test with 2 seizures
iPatients = [1 15];

for iPat = iPatients
    %Prototypes for Seizure or not Seizure event
    queeryVectorS = zeros(seizureN(iPat),D);
    queeryVectornS = zeros(seizureN(iPat),D);
    Seizure = sprintf('Pat%d/Sz1', iPat);
    loading=load(Seizure);
    nSignals = size(loading.EEG,2);
    %% 2.
    rng(1);
    %item memory for channels
    itemMemoryChannel(nSignals);
    %Item memory for LBPs
    itemMemoryLBP(totalNumberBP);
    %% 3.
    %here I create the prototypes for ictal and interictal period from
    %groups of 2 seizures: for patient 1 for example we will have 1-4 2-5
    %and 3-4
    for iSzLearn = 1:ceil(seizureN(iPat)/2)
        %change here if you have the Dataset in one other folder from the
        %running one.
        iSzLearn2 = iSzLearn+ceil(seizureN(iPat)/2);
        if iSzLearn2 > seizureN(iPat)
            iSzLearn2 = iSzLearn2 - ceil(seizureN(iPat)/2) + 1;
        end
        SeizureLearn = [iSzLearn iSzLearn2];
        for i = 1:2
            plotSeizure = sprintf('Pat%d/Sz%d', iPat, SeizureLearn(i));
            printSeizure = sprintf('Pat%d/Sz%d train \n', iPat, SeizureLearn(i));
            loading=load(plotSeizure);
            fprintf(printSeizure);
            %ictal period to learn:self defined by visual inspection of HG and
            %permutation entropy plots
            learningPeriod = tbeginict(iPat,SeizureLearn(i))*fs:tendict(iPat,SeizureLearn(i))*fs;
            [tempS(i,:)] = windowencoding(learningPeriod,loading.EEG, nSignals);  
            %interictal period to learn: always 10-50
            learningPeriod = 10*fs:30*fs;
            [tempnS(i,:)] = windowencoding(learningPeriod,loading.EEG, nSignals);         
        end
        queeryVectorS(iSzLearn,:) = sign(tempS(1,:)+tempS(2,:)+tempS(1,:).*tempS(2,:));
        queeryVectornS(iSzLearn,:) = sign(tempnS(1,:)+tempnS(2,:)+tempnS(1,:).*tempnS(2,:));
    end
%% 4.
    %we test the first 270 seconds, since the onset is already there and
    %we want to detect the onset.
    nSteps = 540;
    global prediction
    global distanceVectors
    global distanceVectorsnS
    %Variable necessary for prediction: they are the distances between the
    %prototypes and the test time-sample
    distanceVectors = zeros(seizureN(iPat),seizureN(iPat) ,nSteps);
    distanceVectorsnS = zeros(seizureN(iPat),seizureN(iPat) ,nSteps);
    prediction = zeros(seizureN(iPat),seizureN(iPat) ,nSteps);
    for iSzTest = 1:seizureN(iPat)
        Seizure = sprintf('Pat%d/Sz%d', iPat, iSzTest);
        printSeizure = sprintf('Pat%d/Sz%d test \n', iPat, iSzTest);
        loading = load(Seizure);
        fprintf(printSeizure);       
        Steps = (1:nSteps)*fs/2-fs/2 + 1;
        %here we test individual windows of 0.5 seconds not overlapping and
        %we give a label to them, Ictal or Interictal: then we will yet
        %pass inside a majority voter
        for iStep = Steps
            learningPeriod = iStep:iStep+255;                     
            [testVector] = windowencoding(learningPeriod,loading.EEG, nSignals);
            testTime(queeryVectorS,queeryVectornS,testVector,iSzTest,iStep);
        end 
    end
    %% 6.
    
    % Save in the folder binary_data the predictions: you have to create
    % that folder
    savestring = sprintf('binary_data/Pat%d_predictions', iPat);
    save(savestring, 'prediction');   
end
%OUTPUT FILES: the output of this script are a serie of tables with
%predictions for individual patient.
