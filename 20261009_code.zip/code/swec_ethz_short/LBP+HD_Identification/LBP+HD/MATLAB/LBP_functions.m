function message = LBP_encoding
    assignin('base', 'itemMemoryChannel', @itemMemoryChannel);
    assignin('base', 'itemMemoryLBP', @itemMemoryLBP);
    assignin('base', 'windowencoding', @windowencoding);
    assignin('base', 'testTime', @testTime);
    message = 'Importing functions from workspace'
end


function [] = itemMemoryChannel(nSignals)
%this function create the sandwich memory for channels
    global IDxHV
    global D
    IDxHV = zeros(length(1:nSignals),D); 
    for i = 1 : 2 : nSignals
        randomIndex = randperm (D);
        IDxHV(i,randomIndex(1 : D/2)) = 1;
        IDxHV(i,randomIndex(D/2+1 : D)) = -1;
    end
    for i = 2 : 2 : nSignals-1
        IDxHV(i, (1 : D/2)) = IDxHV(i-1,(1 : D/2));
        IDxHV(i, (D/2+1: D)) = IDxHV(i+1,(D/2+1 : D));
    end
        IDxHV(nSignals, (1 : D/2)) = IDxHV(nSignals-1, (1 : D/2));
        randomIndex = randperm (D/2)+D/2;
        IDxHV(nSignals, randomIndex(1:D/4)) =  1;       
        IDxHV(nSignals, randomIndex(D/4+1: D/2)) =  -1;
end


function [] = itemMemoryLBP(totalNumberBP)
%this create a simple pseudo-orthogonal set of HVs
    global IDbpHV
    global D  
    IDbpHV = zeros(length(1:totalNumberBP),D);  
    for IDind = 1:totalNumberBP
        randomIndex = randperm (D);
        IDbpHV(IDind,randomIndex(1 : D/2)) = 1;
        IDbpHV(IDind,randomIndex(D/2+1 : D)) = -1;
    end
end


function [WindowHV] = windowencoding(learningPeriod,EEG, nSignals)
%This function return the encoded HV of a window of time
%INPUTS:
%    - learningPeriod: Window of time that we will learn in the form of
%    individual sample points;
%    - EEG: trivial;
%    - nSignals: number of channels of the specific patient
%OUTPUTS:
%    - windowHV: HV that encodes the period of time
    global IDbpHV
    global IDxHV  
    global T
    global dT
    global D
    WindowHV = zeros(1,D);
    for iStep = learningPeriod;
            x = EEG ((iStep -1)*dT + 1: (iStep-1)*dT + T, :);
            bp = num2str((diff(x)>0)');
            bpNo = bin2dec(bp)+1; 
            bindingVector=sum(IDxHV(:,:).*IDbpHV(bpNo,:));      
        if mod(nSignals,2)==0
            bindingVector = bindingVector + IDbpHV(1,:).*IDbpHV(2,:);
        end
        WindowHV = WindowHV + sign(bindingVector);
    end % end of: for each time step
    WindowHV = sign(WindowHV);
end


function [] = testTime(queeryVectorS,queeryVectornS,testVector, iSzTest,iStep)
% in the function I test the test window to assign a label to that: I test
% it using all the different seizures to test.
%INPUTS:
%    - queeryVectorS: Prototype for the ictal period;
%    - queeryVectornS: Prototype for the interictal period;
%    - testVector: HV to be tested, corresponding to a window of 0.5
%    seconds
%    - iSzTest: Seizure under test; needed to record the prediction in the
%    right position
%    - iStep: number of the window inside the recording: also this variable
%    is used for storing
%OUTPUTS:
    global prediction
    global distanceVectors
    global distanceVectorsnS
    global D
    testVectorcompare =ones(size(queeryVectorS,1),1)*testVector;
    distanceVectors(:,iSzTest, (iStep+255)/256) = sum(testVectorcompare.*queeryVectorS,2)/D; 
    distanceVectorsnS(:,iSzTest, (iStep+255)/256) = sum(testVectorcompare.*queeryVectornS,2)/D; 
    for i = 1:size(distanceVectors,1) 
        if distanceVectors(i,iSzTest, (iStep+255)/256) > distanceVectorsnS(i,iSzTest, (iStep+255)/256)
            prediction(i,iSzTest, (iStep+255)/256) = 1;
        else
            prediction(i,iSzTest, (iStep+255)/256) = 0;
        end
    end
end