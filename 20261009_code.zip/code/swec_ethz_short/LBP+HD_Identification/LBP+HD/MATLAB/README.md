## MATLAB files description
* **`LBP_functions.m`**:
This file contains the function for the 2 successive files. It has not to be executed, only present in the folder where the other files are executed.
* **`Binary_pattern_script.m`**:
You should use this script to test all the patient with a single seizure used to train. Inside there is a vector iPatients to select the patient that you want to test.
To execute him, change the vector iPatients with the Patients that you want to test, put LBP_functions in the same folder and create a folder 'binary_data' in the execution directory to put the output files inside. Is very slow to execute. Better to execute in the night if you want to train all the nine patient that have a good prevision with 1 training seizure.  
**N.B.** for patient9 the Seizure 3 has to be excluded since full of artifacts : so in the final table of prediction of Postprocessing.m  you have to neglect row 3 and column 3.
* **`Binary_pattern_script_multipleSeizures.m`**:
Same consideration of previous file: this script is usefull for patient 1/15 that are tested with 2 seizures.
* **`Postprocessing.m`**:
Here you do the postprocessing patient per patient using the output files of previous scripts. A variable, iPatient, let you decide the patient that you want to postprocess. Is very fast to execute (< 1 second)
