%   Binary_pattern_script.m
%   Alessio Burrello
%   Last modification: 26-04-2018

%the aim of the script is to apply the majority rule and so the post
%processing to the input row prediction files
%INPUTS
%   - Pati_predictions.mat: it contains the raw predictions of each patient
%OUTPUT
%   -final_prediction: matrix containing on the columns the training
%   seizures and on the rows the tested seizures: inside there is the time
%   of the prediction: if 0, the seizure is not predicted

%% Initial loading of data and trasformation in 2D
clear all
close all
iPatient = 9;   %set this variable to change the patient to analyze
iSez = [5 4 14 4 6 2 7 3 7 13 2 10 2 10 9 2];   %number of seizure of each patient
%this variable indicates the number of time samples inside the window that
%should be predicted as 1 to identify a seizure! It is tuned per patient!
Majority_voter = [10/10 9/10 1 10/10 10/10 9/10 1 8/10 10/10 1 10/10 1 9/10 1 10/10 9/10];
Patient = sprintf ('/home/msc18f3/Documents/ETH/binary_data/Pat%d_predictions.mat', iPatient);
load (Patient);
%trasforming the 3D matrix in a 2D one for the succesive part of the script
n = iSez(iPatient);
m = n;
for i = 1:n
    for j=1:m
        predi((i-1)*m+j,:)=prediction(i,j,:);
    end
end

%% FINAL POST PROCESSING, MAJORITY VOTER
%I do the mean of 10 successive time sample, i.e. a window of 5 seconds,
%overlapping of 4.5 seconds
for i = 10:540
    prediction_mean(:,i)=mean(predi(:,i-9:i)')';
end
%Applying the majority rule, saved differently for each patient inside a
%vector
prediction_mean = prediction_mean >= Majority_voter(iPatient);
locked=zeros(1,size(predi,1));
index = zeros(1,m*n);
for i = 1:size(prediction_mean,2)
    for j = 1:size(prediction_mean,1)
        if prediction_mean(j,i) == 1 && locked(j)==0
            index(j) = i;
            locked(j)=1;
        end
    end
end
%%train on y axis, test on x axis
switch iPatient
    case 1
    temp = index(1:ceil(iSez(iPatient)/2)*m);
    temp = temp'/2;
    FinalPrediction = reshape(temp, [m ceil(n/2)])
    case 15
    temp = index(1:ceil(iSez(iPatient)/2)*m);
    temp = temp'/2;
    FinalPrediction = reshape(temp, [m ceil(n/2)])
    otherwise
    temp = index;
    temp = temp'/2;
    FinalPrediction = reshape(temp, [m n])
end

%In FinalPrediction I have a matrix with prevision of every recording using
%one or a group of seizures: they are displayed in a table.
