#!/usr/bin/env python
"""
iEEGClassifierLBP+HD.py - Python 3 / PyTorch 2 port (Burrello et al., BioCAS 2018)

Trains the LBP+HD classifier on 1..n seizures and tests it on every seizure of the
patient, for each cross-validation fold. One prediction file per (seizure, fold) is
written to  results\\swec_short\\LBP+HD\\predictions\\Pat<n>\\ .

Run (PowerShell, .venv active, from this folder):
    $env:SWEC_PATIENT = 6
    python "iEEGClassifierLBP+HD.py"
then run HD_PostProcessing.py with the same SWEC_PATIENT.
Other settings: see swec_config.py.

Changes vs. the original are marked "PORT:".
"""
import sys
import os
import time

import numpy as np
import scipy.io as scp
import torch

from iEEGFunctions import HD_classifier   # here there are all the functions that we use
import swec_config as cfg                 # PORT: shared paths/tables/device for both scripts

__author__ = "Alessio Burrello"
__email__ = "alessio.burrello@studenti.polito.it"

# PORT: was  device = 1; torch.cuda.set_device(device)   (second GPU of the ETH server)
device = cfg.get_device()
# Patient 9, the third seizure is an artifact!
Seizure_train = cfg.Seizure_train
seizureN = cfg.seizureN
fs = cfg.FS
# table that represents all the ictal segments used to train with each different
# patient and seizure (seconds from the start of each recording)
Seizure_begin = [[184, 184, 183, 186, 186, 0,   0,   0,   0,   0, 0, 0, 0, 0],
                 [180, 192, 188, 186, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
                 [181, 207, 231, 190, 190, 196, 193, 202, 205, 201, 195, 195, 194, 191],
                 [220, 219, 200, 192, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
                 [187, 188, 208, 202, 202, 212,   0,   0,   0,   0, 0, 0, 0, 0],
                 [184, 186, 0, 0, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
                 [200, 210, 200, 200, 220, 200, 200,   0,   0,   0, 0, 0, 0, 0],
                 [185, 188, 185, 0, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
                 [188, 204, 204, 214, 183, 203, 185,   0,   0,   0, 0, 0, 0, 0],
                 [181, 185, 182, 182, 181, 182,   180,   184, 181, 180, 181, 182, 180, 0],
                 [181, 180, 0, 0, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
                 [210, 210, 200, 220, 200, 200, 210, 200, 200, 190, 0, 0, 0, 0],
                 [185, 185, 0, 0, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
                 [195, 185, 194, 195, 184, 185, 235, 185, 182, 185, 0, 0, 0, 0],
                 [213, 208, 200, 204, 210, 200, 216, 205, 203,   0, 0, 0, 0, 0],
                 [205, 195, 0, 0, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0]]
Seizure_end = [[192, 193, 189, 190, 200, 0,   0,   0,   0,   0, 0, 0, 0, 0],
               [210, 215, 215, 215, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
               [200, 230, 255, 220, 219, 219, 215, 228, 228, 226, 220, 213, 218, 210],
               [250, 255, 239, 217, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
               [225, 218, 234, 231, 221, 242,   0,   0,   0,   0, 0, 0, 0, 0],
               [193, 195, 0, 0, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
               [220, 230, 220, 220, 240, 225, 220,   0,   0,   0, 0, 0, 0, 0],
               [205, 205, 210, 0, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
               [201, 231, 210, 244, 195, 226, 211,   0,   0,   0, 0, 0, 0, 0],
               [189, 190, 196, 190, 183, 188,   181,   193, 190, 189, 191, 199, 181, 0],
               [211, 210, 0, 0, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
               [225, 225, 215, 230, 220, 220, 220, 220, 220,   0, 0, 0, 0, 0],
               [210, 210, 0, 0, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0],
               [210, 200, 218, 219, 214, 220, 268, 220, 222, 222, 0, 0, 0, 0],
               [238, 225, 225, 234, 235, 225, 241, 225, 233,   0, 0, 0, 0, 0],
               [235, 225, 0, 0, 0, 0,   0,   0,   0,   0, 0, 0, 0, 0]]
second = fs
minutes = second * 60
T = 7        # 1 + dimension l of binary pattern
totalNumberBP = 2 ** (T - 1)
D = 10000    # dimension of hypervector
half = fs // 2   # PORT: fs/2 -> fs//2 (0.5 s window = 256 samples)
# List of patient that we want to test
PatientList = cfg.patients_from_env(default=[2])   # PORT: was PatientList = [2]
# PORT: the original training loop read file Sz{i+1+cross} but its ictal times from
# column i, i.e. the wrong seizure whenever cross > 0. Fixed to column i+cross.
# Set SWEC_ORIGINAL_TRAIN_INDEX=1 to reproduce the original behaviour exactly.
ORIGINAL_TRAIN_INDEX = os.environ.get("SWEC_ORIGINAL_TRAIN_INDEX", "0") == "1"


def load_eeg(path):
    """EEG matrix as stored: samples x channels."""
    return np.asarray(scp.loadmat(str(path), variable_names=["EEG"])["EEG"])


print(f"[run] device={device}  seed={cfg.seed()}  folds={os.environ.get('SWEC_FOLDS', 'full')}  "
      f"original_train_index={ORIGINAL_TRAIN_INDEX}  fast_encoder={os.environ.get('SWEC_FAST', '1') != '0'}")

for Patient in PatientList:
    K = cfg.folds(Patient)
    # PORT: the original read this first file from Pat{Patient_trasformation[Patient-1]} and all
    # others from Pat{Patient}; one consistent folder is used here (see swec_config.mapping()).
    first = load_eeg(cfg.seizure_file(Patient, 1))
    nSignals = first.shape[1]
    del first
    print(f"\n=== Patient {Patient} -> {cfg.data_folder(Patient).name}: {nSignals} channels, "
          f"{seizureN[Patient-1]} seizures, train on {Seizure_train[Patient-1]}, {K} fold(s) ===")
    torch.manual_seed(cfg.seed())
    # creating the model with the 2 itemMemory, both random and binarized
    model = HD_classifier(totalNumberBP, D, nSignals, T, device, 'random')
    t_patient = time.time()
    for cross in range(K):
        ####TRAINING####
        for i in range(Seizure_train[Patient-1]):
            sz = i + 1 + cross
            col = i if ORIGINAL_TRAIN_INDEX else i + cross
            eeg = load_eeg(cfg.seizure_file(Patient, sz))
            seg = eeg[Seizure_begin[Patient-1][col]*fs:Seizure_end[Patient-1][col]*fs, :]
            EEGSez = torch.from_numpy(np.ascontiguousarray(seg)).to(device).t()
            print(f'Learning Seizure number {sz}  ({Seizure_begin[Patient-1][col]}-{Seizure_end[Patient-1][col]} s)')
            temp1 = model.learn_HD_proj_big_half(EEGSez, fs)
            # I use the first seizure to create the HV: if we have more than 1, I will sum the other
            # to the first HV and perform an other binarization of the HV.
            if i == 0:
                queeryVectorS0 = temp1
            else:
                queeryVectorS0 = queeryVectorS0 + temp1
        queeryVectorS0 = (queeryVectorS0 > Seizure_train[Patient-1] // 2).short()
        eeg = load_eeg(cfg.seizure_file(Patient, 1))
        EEGInterictal = torch.from_numpy(np.ascontiguousarray(eeg[10*fs:50*fs, :])).to(device).t()
        print('Learning Interictal period')
        temp3 = model.learn_HD_proj_big_half(EEGInterictal, fs)
        queeryVectornS0 = temp3
        ####TESTING####
        t = time.time()
        for j in range(1, seizureN[Patient-1] + 1):
            eeg = load_eeg(cfg.seizure_file(Patient, j))
            EEGtest = torch.from_numpy(eeg).to(device).t()
            index = np.arange(0, EEGtest.size(1), half)
            # PORT: was torch.zeros(1, f['EEG'].shape[0]/fs*2) (float size in Python 3)
            distanceVectorsS0 = torch.zeros(1, len(index), device=device)
            distanceVectorsnS0 = torch.zeros(1, len(index), device=device)
            prediction0 = torch.zeros(1, len(index), device=device)
            t_sz = time.time()
            for i, iStep in enumerate(index):
                temp = model.learn_HD_proj(EEGtest[:, iStep:iStep + half])
                [distanceVectorsS0[0, i], distanceVectorsnS0[0, i], prediction0[0, i]] = \
                    model.predict(temp, queeryVectorS0, queeryVectornS0, D)
            # PORT: the original printed every half second; one line per seizure instead
            print(f'Patient {Patient} fold {cross+1}/{K} seizure {j}/{seizureN[Patient-1]}: '
                  f'{len(index)} windows, {int(prediction0.sum().item())} predicted ictal, {time.time()-t_sz:.1f} s')
            # for the purpose of this code, we save only prediction, discarding the 2 distances from the 2 prototypes
            out = cfg.prediction_file(Patient, j, cross)
            out.parent.mkdir(parents=True, exist_ok=True)
            torch.save(prediction0[0, :].cpu(), out)
    print(f'Patient {Patient} finished in {(time.time()-t_patient)/60:.1f} min. '
          f'Predictions in {cfg.PRED_DIR / ("Pat" + str(Patient))}')
# PORT: all paths now come from swec_config.py (the original pointed to the ETH network).
