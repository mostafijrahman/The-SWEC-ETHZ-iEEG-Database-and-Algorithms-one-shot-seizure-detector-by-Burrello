#!/usr/bin/env python
"""
swec_config.py  (NEW file added for the Python 3 / PyTorch 2 port)

Settings shared by iEEGClassifierLBP+HD.py and HD_PostProcessing.py, so the two
scripts always agree on paths, folds, patient numbers and device.

All numeric tables are copied verbatim from the original ETH Zurich scripts.

Environment variables (set in PowerShell with  $env:NAME = "value"):
  SWEC_PATIENT   patient number(s) as used in the scripts: "6", "1,2,3" or "all"
  SWEC_FOLDS     "full" (default) = sliding-window CV, K = seizures - train + 1
                 "original"       = the shorter K list hard-coded in the classifier
                 "<n>"            = only the first n folds (quick test)
  SWEC_GPU       GPU index (default 0). CPU is used if CUDA is unavailable.
  SWEC_SEED      torch.manual_seed for the random item memories (default 1, as original)
  SWEC_ID_MAP    force the patient -> data-folder mapping: direct | transform | inverse
  SWEC_ROOT      project root (default C:\\Users\\mrahman\\sEEG)
"""
import os
from pathlib import Path

import torch

# ---------------------------------------------------------------- paths
PROJECT_ROOT = Path(os.environ.get("SWEC_ROOT", r"C:\Users\mrahman\sEEG"))
DATA_DIR = PROJECT_ROOT / "data" / "raw" / "swec_ethz_short"          # ID1..ID16\Sz*.mat
RESULTS_DIR = PROJECT_ROOT / "results" / "swec_short" / "LBP+HD"
PRED_DIR = RESULTS_DIR / "predictions"

FS = 512

# ---------------------------------------------------------------- tables (verbatim)
# number of seizures of each patient
seizureN = [5, 4, 14, 4, 6, 2, 7, 3, 7, 13, 2, 10, 2, 10, 9, 2]
# number of seizures used for training (iEEGClassifierLBP+HD.py; patient 9 = 4,
# "the third seizure is an artifact!"). HD_PostProcessing.py had 3 for patient 9 but never used it.
Seizure_train = [2, 1, 3, 1, 1, 1, 3, 1, 4, 3, 1, 6, 1, 4, 2, 1]
# folds hard-coded in HD_PostProcessing.py  (== seizureN - Seizure_train + 1 for every patient)
crossValidationK_full = [4, 4, 12, 4, 6, 2, 5, 3, 4, 11, 2, 5, 2, 7, 8, 2]
# folds hard-coded in iEEGClassifierLBP+HD.py (1 fold for patients 3, 7, 9, 10, 12, 14)
crossValidationK_original = [4, 4, 1, 4, 6, 2, 1, 3, 1, 1, 2, 1, 2, 1, 8, 2]
# post-processing threshold of each patient (HD_PostProcessing.py)
threshold = [-9.5/10, -9.5/10, -7.5/10, -9.5/10, -9.5/10, -8.5/10, -9.5/10, -7.5/10,
             -8.5/10, -8.5/10, -9.5/10, -6.5/10, -8.5/10, -5.5/10, -9.5/10, -8.5/10]
# "inserted to match the ID of the anonymous dataset uploaded on the webpage, with the ID of the paper"
Patient_trasformation = [10, 6, 4, 2, 16, 7, 14, 15, 13, 1, 8, 5, 3, 12, 9, 11]
_inverse = [0] * 16
for _k, _v in enumerate(Patient_trasformation):
    _inverse[_v - 1] = _k + 1

assert all(n - t + 1 == k for n, t, k in zip(seizureN, Seizure_train, crossValidationK_full))

# ---------------------------------------------------------------- run settings
def get_device() -> torch.device:
    gpu = int(os.environ.get("SWEC_GPU", "0"))
    if torch.cuda.is_available():
        return torch.device(f"cuda:{gpu}")
    return torch.device("cpu")


def seed() -> int:
    return int(os.environ.get("SWEC_SEED", "1"))


def patients_from_env(default):
    raw = os.environ.get("SWEC_PATIENT", "").strip().lower()
    if not raw:
        print(f"[config] SWEC_PATIENT not set - using default {default}")
        return list(default)
    if raw == "all":
        return list(range(1, 17))
    pats = [int(p) for p in raw.replace(" ", "").split(",") if p]
    for p in pats:
        if not 1 <= p <= 16:
            raise ValueError(f"SWEC_PATIENT must be 1..16, got {p}")
    return pats


def folds(patient: int) -> int:
    mode = os.environ.get("SWEC_FOLDS", "full").strip().lower()
    full = crossValidationK_full[patient - 1]
    if mode == "full":
        return full
    if mode == "original":
        return crossValidationK_original[patient - 1]
    return max(1, min(int(mode), full))


# ---------------------------------------------------------------- data folders
_MAPS = {
    "direct": lambda p: p,                                   # script patient p -> ID{p}
    "transform": lambda p: Patient_trasformation[p - 1],     # p -> ID{Patient_trasformation[p-1]}
    "inverse": lambda p: _inverse[p - 1],                    # the reverse direction
}
_mapping_cache = None


def _count_seizures(folder_id: int):
    d = DATA_DIR / f"ID{folder_id}"
    if not d.is_dir():
        return None
    return sum(1 for _ in d.glob("Sz*.mat"))


def mapping() -> str:
    """Pick the patient-number -> data-folder mapping whose seizure counts match seizureN.

    The original scripts are inconsistent (Pat{Patient} in some lines,
    Pat{Patient_trasformation[Patient-1]} in others), so we test the downloaded data.
    """
    global _mapping_cache
    if _mapping_cache:
        return _mapping_cache
    forced = os.environ.get("SWEC_ID_MAP", "").strip().lower()
    if forced:
        if forced not in _MAPS:
            raise ValueError(f"SWEC_ID_MAP must be one of {list(_MAPS)}")
        _mapping_cache = forced
        print(f"[config] patient->folder mapping forced to '{forced}'")
        return forced
    scores = {}
    for name, f in _MAPS.items():
        ok = bad = 0
        for p in range(1, 17):
            c = _count_seizures(f(p))
            if c is None:
                continue
            ok, bad = (ok + 1, bad) if c == seizureN[p - 1] else (ok, bad + 1)
        scores[name] = (ok, bad)
    good = [n for n, (ok, bad) in scores.items() if bad == 0 and ok > 0]
    if not good:
        lines = [f"  {n:<9} matching patients={ok}, mismatching={bad}" for n, (ok, bad) in scores.items()]
        raise RuntimeError(
            "Seizure-file counts in " + str(DATA_DIR) + " do not match the paper's table "
            "under any patient mapping:\n" + "\n".join(lines) +
            "\nRun scripts\\verify_swec_short.py and check the downloads.")
    best = max(good, key=lambda n: scores[n][0])
    ties = [n for n in good if scores[n][0] == scores[best][0]]
    if len(ties) > 1:
        best = ties[0]
        print(f"[config] mappings {ties} fit equally well (download more patients to disambiguate); using '{best}'")
    _mapping_cache = best
    print(f"[config] patient->folder mapping: '{best}' ({scores[best][0]} patients checked)")
    return best


def data_folder(patient: int) -> Path:
    return DATA_DIR / f"ID{_MAPS[mapping()](patient)}"


def seizure_file(patient: int, seizure: int) -> Path:
    path = data_folder(patient) / f"Sz{seizure}.mat"
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def prediction_file(patient: int, seizure: int, cross: int) -> Path:
    # PORT: the original scripts used different names (classifier: ...Seizure{j}Cross{c}.txt,
    # post-processing: ...Seizure{j}Win256Cross{c}.txt) and different folders; unified here.
    return PRED_DIR / f"Pat{patient}" / f"HDClassifier_Seizure{seizure}Cross{cross}.pt"
