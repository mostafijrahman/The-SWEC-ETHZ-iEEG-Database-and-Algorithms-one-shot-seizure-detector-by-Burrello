#!/usr/bin/env python
"""
paper_protocol_metrics.py  (NEW - put next to HD_PostProcessing.py)

Recomputes LBP+HD metrics from the saved prediction files under two protocols:
  released : what HD_PostProcessing.py reports - every recording in every fold that was run
             (SWEC_FOLDS), including the seizures used for training
  paper    : BioCAS 2018 protocol - unseen seizures only;
             Table I patients: k-fold;  Table II patients (3,7,9,10,12,14): fold 0 only
             (train on the first m seizures, test on the remaining ones)
Works with SWEC_FOLDS=full (lab run) and SWEC_FOLDS=original (paper protocol only).
Patients without prediction files are skipped.
Same moving-average/threshold/delay logic as HD_PostProcessing.py. No classifier re-run needed.

Usage:  python paper_protocol_metrics.py
Output: results\\swec_short\\LBP+HD\\LBPHD_replication_vs_BioCAS2018.csv
"""
import csv
import numpy as np
import torch
import swec_config as cfg

dim, TS = 5, 10
PRE = 170 * 10 / dim                      # first 170 s = 340 half-second windows
TABLE2 = {3, 7, 9, 10, 12, 14}
PAPER = {1: (6.3, 100, 100), 2: (15.1, 100, 100), 4: (34.5, 100, 100), 5: (20.9, 100, 100), 6: (6.3, 100, 100),
         8: (13.2, 100, 100), 11: (7.0, 100, 100), 13: (10.0, 100, 100), 15: (36.4, 100, 100), 16: (32.3, 100, 100),
         3: (21.8, 94.17, 100), 7: (5.0, 44, 100), 9: (16.2, 100, 100), 10: (9.3, 99.47, 90),
         12: (12.6, 93.10, 100), 14: (21.7, 100, 100)}   # (mean delay s, spe %, sen %) from Tables I-II
ORDER = [1, 2, 4, 5, 6, 8, 11, 13, 15, 16, 3, 7, 9, 10, 12, 14]


def analyse(p, folds, exclude_train):
    m = cfg.Seizure_train[p - 1]
    fp = n_rec = det = 0
    delays = []
    for c in folds:
        train = set(range(c + 1, c + m + 1))          # seizures trained on in fold c
        for s in range(1, cfg.seizureN[p - 1] + 1):
            if exclude_train and s in train:
                continue
            pred = torch.load(cfg.prediction_file(p, s, c), map_location="cpu")
            pm = torch.zeros(pred.numel())
            for k in range(TS, pred.numel()):
                pm[k] = torch.mean(pred[k - TS:k])
            fin = torch.sign(pm + cfg.threshold[p - 1])
            first = True
            n_rec += 1
            for k in range(fin.numel()):
                if fin[k] == 1 and first and k > PRE:
                    det += 1
                    delays.append(k / (10 / dim) - 180)
                    first = False
                elif fin[k] == 1 and k < PRE:
                    fp += 1
    return dict(n=n_rec, spe=round((1 - fp / (PRE * n_rec)) * 100, 2), sen=round(det / n_rec * 100, 2),
                delay=round(float(np.mean(delays)), 2) if delays else float("nan"))


out = cfg.RESULTS_DIR / "LBPHD_replication_vs_BioCAS2018.csv"
with open(out, "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["paper_table", "patient", "dataset_folder", "test_recordings",
                "paper_delay_s", "paper_spe", "paper_sen", "repl_delay_s", "repl_spe", "repl_sen", "delay_diff_s",
                "released_delay_s", "released_spe", "released_sen"])
    for p in ORDER:
        run_folds = range(cfg.folds(p))
        if not cfg.prediction_file(p, cfg.seizureN[p - 1], run_folds[-1]).exists():
            print(f"P{p:<3} skipped - predictions missing (run the classifier for this patient)")
            continue
        rel = analyse(p, run_folds, exclude_train=False)
        pap = analyse(p, [0] if p in TABLE2 else run_folds, exclude_train=True)
        d, s, n = PAPER[p]
        row = ["II" if p in TABLE2 else "I", p, cfg.data_folder(p).name, pap["n"], d, s, n,
               pap["delay"], pap["spe"], pap["sen"], round(pap["delay"] - d, 2), rel["delay"], rel["spe"], rel["sen"]]
        w.writerow(row)
        print(f"P{p:<3} paper {d:>5}/{s:>6}/{n:>4}   replication {pap['delay']:>6}/{pap['spe']:>6}/{pap['sen']:>6}")
print(f"\nWritten to {out}")
