#!/usr/bin/env python
'''
Local sensitive Hashing function

Python 3 / PyTorch 2 port of the ETH Zurich iEEGFunctions.py (Burrello et al., BioCAS 2018).
Changes are marked "PORT:". Summary:
  * runs on CPU or any GPU (original: CUDA only, torch.cuda.*Tensor constructors)
  * deprecated torch.add(a, 1, b) calls rewritten as a + b
  * Python 3 integer division (fs/2 -> fs//2, HD_dim/2 -> HD_dim//2, (T-1)/2 -> (T-1)//2)
  * learn_HD_proj has a vectorised implementation that gives bit-identical results
    (set SWEC_FAST=0 to use the original sample-by-sample loop instead)
'''
import time, sys
import os
import math

import numpy as np
import scipy.special
import torch

__author__ = "Alessio Burrello"
__email__ = "alessio.burrello@studenti.polito.it"

# PORT: default device for the LBP/LGP feature functions used by the baselines
DEFAULT_DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def _as_device(device):
    # PORT: original passed a GPU index; accept an index, a string or a torch.device
    if isinstance(device, torch.device):
        return device
    if isinstance(device, int):
        return torch.device(f"cuda:{device}") if torch.cuda.is_available() else torch.device("cpu")
    return torch.device(device)


class HD_classifier:

    def __init__(self, N_seats1, HD_dim, N_seats2, T, device, string, cuda=True):
        ''' Initialize an HD classifier using the torch library
        Parameters
        ----------
        N_seats1: number of elements inside the LBP item memory
        HD_dim: dimension of the HD vectprs
        N_seats2: number of channels of the channels item memory
        T: LBP length + 1
        device: device used to create the itemMemory (PORT: GPU index, "cpu" or torch.device)
        string: type of item Memory for the channel item Memory: random or sandwich
        cuda: PORT: ignored, the device decides.
        '''
        self.training_done = False
        self.N_seats1 = N_seats1
        self.N_seats2 = N_seats2
        self.HD_dim = HD_dim
        self.T = T
        self.device = _as_device(device)
        # creation of a random itemMemory of 1 and 0 of dimension N_seats1xHD_dim
        # PORT: random numbers are drawn on the CPU and then moved, exactly like the
        # original torch.randn(...).cuda(), so the same seed gives the same memory on CPU and GPU.
        self.proj_mat_LBP = torch.randn(self.HD_dim, self.N_seats1).to(self.device)
        self.proj_mat_LBP[self.proj_mat_LBP > 0] = 1
        self.proj_mat_LBP[self.proj_mat_LBP <= 0] = 0
        # creation of a sandwich itemMemory of 1 and 0 of dimension N_seats2xHD_dim: the single
        # hypervectors inside the memory are similar to adiacent ones (~75% equal) and pseudo orthogonal
        # with the others.
        if string == 'sandwich':
            self.proj_mat_channels = torch.zeros(self.HD_dim, self.N_seats2, device=self.device)
            for i in range(N_seats2):
                if i % 2 == 0:
                    self.proj_mat_channels[:, i] = torch.randn(self.HD_dim, 1).view(-1).to(self.device)
                    self.proj_mat_channels[self.proj_mat_channels > 0] = 1
                    self.proj_mat_channels[self.proj_mat_channels <= 0] = 0
            h = HD_dim // 2   # PORT: HD_dim/2 -> HD_dim//2
            for i in range(N_seats2 - 1):
                if i % 2 == 1:
                    self.proj_mat_channels[0:h, i] = self.proj_mat_channels[0:h, i - 1]
                    self.proj_mat_channels[h:HD_dim, i] = self.proj_mat_channels[h:HD_dim, i + 1]
            self.proj_mat_channels[0:h, N_seats2 - 1] = self.proj_mat_channels[0:h, N_seats2 - 2]
            self.proj_mat_channels[h:HD_dim, N_seats2 - 1] = torch.randn(self.HD_dim // 2, 1).view(-1).to(self.device)
            self.proj_mat_channels[self.proj_mat_channels > 0] = 1
            self.proj_mat_channels[self.proj_mat_channels <= 0] = 0
        # creation of a random itemMemory of 1 and 0 of dimension N_seats2xHD_dim
        elif string == 'random':
            self.proj_mat_channels = torch.randn(self.HD_dim, self.N_seats2).to(self.device)
            self.proj_mat_channels[self.proj_mat_channels >= 0] = 1
            self.proj_mat_channels[self.proj_mat_channels < 0] = 0

        # PORT: helpers for the vectorised encoder (same values, compact dtypes)
        self.LBP_weights = torch.tensor([2**0, 2**1, 2**2, 2**3, 2**4, 2**5], dtype=torch.int16, device=self.device)
        self._lbp_u8 = self.proj_mat_LBP.to(torch.uint8)
        self._ch_u8 = self.proj_mat_channels.to(torch.uint8)
        self._tie = self.xor(self.proj_mat_LBP[:, 1], self.proj_mat_LBP[:, 2]).to(torch.int32)
        self.fast = os.environ.get("SWEC_FAST", "1") != "0"
        self.chunk = int(os.environ.get("SWEC_CHUNK", "32"))

    def learn_HD_proj(self, EEG):
        ''' starting from EEG data, it creates the histogram of LBP for the target segment
        projecting it in the HD space.
        Parameters
        ----------
        EEG: samples of EEG on multiple channels.
        Return
        ------
        quueryVector: HV in which all the histograms among all the channels are encoded.
        '''
        if self.fast and EEG.size(1) - 6 > 0:
            return self._learn_HD_proj_fast(EEG)
        return self.learn_HD_proj_reference(EEG)

    def learn_HD_proj_reference(self, EEG):
        ''' PORT: the original sample-by-sample algorithm, only API-modernised. '''
        queeryVector = torch.zeros(1, 1, dtype=torch.int16, device=self.device)
        N_channels, learningEnd = EEG.size()
        LBP_weights = self.LBP_weights
        for iStep in range(learningEnd - 6):
            x = EEG[:, iStep:(iStep + self.T)].short()
            bp = ((x[:, 1:self.T] - x[:, 0:self.T - 1]) > 0).short()   # PORT: was torch.add(-x[..], 1, x[..])
            value = torch.sum(torch.mul(LBP_weights, bp), dim=1)
            bindingVector = self.xor(self.proj_mat_channels, self.proj_mat_LBP[:, value.long()])
            output_vector = torch.sum(bindingVector, dim=1)
            # here we broke ties summing an additional HV in case of an even number
            if N_channels % 2 == 0:
                output_vector = self.xor(self.proj_mat_LBP[:, 1], self.proj_mat_LBP[:, 2]) + output_vector
            output_vector = (output_vector > int(math.floor(self.N_seats2 / 2))).short()
            queeryVector = queeryVector + output_vector
        queeryVector = (queeryVector > (learningEnd - 6) // 2).short()   # PORT: py2 int division
        return queeryVector

    def _learn_HD_proj_fast(self, EEG):
        ''' PORT: vectorised version of learn_HD_proj_reference (bit-identical output).
        Computes all LBP codes at once, then encodes `chunk` time steps per tensor operation.
        '''
        N_channels, learningEnd = EEG.size()
        n_steps = learningEnd - 6
        xs = EEG[:, :n_steps + self.T - 1].short()
        d = (xs[:, 1:] - xs[:, :-1] > 0).to(torch.int64)                 # (C, n_steps + T - 2)
        codes = torch.zeros(N_channels, n_steps, dtype=torch.int64, device=self.device)
        for k in range(self.T - 1):
            codes += (2 ** k) * d[:, k:k + n_steps]                       # LBP code of every step
        thr = int(math.floor(self.N_seats2 / 2))
        acc = torch.zeros(self.HD_dim, dtype=torch.int32, device=self.device)
        ch = self._ch_u8.unsqueeze(2)                                     # (D, C, 1)
        for s0 in range(0, n_steps, self.chunk):
            c = codes[:, s0:s0 + self.chunk]                              # (C, S)
            bound = self._lbp_u8[:, c] != ch                              # xor -> (D, C, S)
            out = bound.sum(dim=1, dtype=torch.int32)                     # (D, S)
            if N_channels % 2 == 0:
                out = out + self._tie.unsqueeze(1)
            acc += (out > thr).sum(dim=1, dtype=torch.int32)
        return (acc > n_steps // 2).short().unsqueeze(0)                  # (1, D) like the original

    def learn_HD_proj_big_half(self, EEG, fs):
        ''' Function used during training to take a bigger window of EEG and sum all the histograms
        of LBP frequency of 0.5 seconds windows inside.
        Parameters
        ----------
        EEG: samples of EEG on multiple channels.
        fs: frequency of the signal.
        Return
        ------
        quueryVector: HV in which all the informations of this big window of EEG is encoded.
        '''
        queeryVector = torch.zeros(1, 1, dtype=torch.int16, device=self.device)
        N_channels, learningEnd = EEG.size()
        half = fs // 2   # PORT: fs/2 -> fs//2
        index = np.arange(0, learningEnd, half)
        for iStep in index:
            temp = self.learn_HD_proj(EEG[:, iStep:iStep + half])
            queeryVector = queeryVector + temp
        queeryVector = (queeryVector > index.size // 2).short()
        return queeryVector

    def predict(self, testVector, Ictalprot, Interictalprot, D):
        ''' Prediction function of HD: it gives in addition to the class prediction also the
        distance from the 2 class prototypes.
        Parameters
        ----------
        testVector: HV of the unlabled segment.
        Ictalprot: prototype (HD vector) for the ictal state.
        Interictalprot: prototype (HD vector) for the interictal state.
        Return
        ------
        distanceVectorsS: distance from ictal Prototype
        distanceVectornS: distance from interictal prototype
        prediction: 1 for seizure, 0 for interictal.
        '''
        distanceVectorsS = self.ham_dist(testVector, Ictalprot, D)
        distanceVectorsnS = self.ham_dist(testVector, Interictalprot, D)
        if distanceVectorsS > distanceVectorsnS:
            prediction = 0
        else:
            prediction = 1
        return distanceVectorsS, distanceVectorsnS, prediction

    def xor(self, vec_a, vec_b):
        ''' xor between vec_a and vec_b
        Parameters
        ----------
        vec_a: first vector, torch Short Tensor shape (HD_dim,)
        vec_b: second vector, torch Short Tensor shape (HD_dim,)
        Return
        ------
        vec_c: vec_a xor vec_b
        '''
        vec_c = (torch.add(vec_a, vec_b) == 1).short()  # xor
        return vec_c

    def ham_dist(self, vec_a, vec_b, D):
        ''' calculate relative hamming distance
        Parameters
        ----------
        vec_a: first vector, torch Short Tensor shape (HD_dim,)
        vec_b: second vector, torch Short Tensor shape (HD_dim,)
        Return
        ------
        rel_dist: relative hamming distance
        '''
        vec_c = self.xor(vec_a, vec_b)
        rel_dist = torch.sum(vec_c) / float(D)
        return rel_dist


# ------------------------------------------------------------------------------------------
# Feature extractors used by the LBP+SVM / LGP+MLP baselines (not used by LBP+HD).
# PORT: device-agnostic; torch.cuda.FloatTensor(...) -> torch.zeros(..., device=...).
# ------------------------------------------------------------------------------------------

def LBP_window_train(EEG, fs, totalNumberBP, label, T, device=None):
    ''' Function used during training to take a bigger window of EEG and sum all the histograms
    of LBP frequency of 0.5 seconds windows inside.
    Return: Vector for train of dimension numberOfWindowsx(2^(T-1)xnChannels).
    '''
    device = device or EEG.device
    N_channels, learningEnd = EEG.size()
    half = fs // 2
    index = np.arange(0, learningEnd, half)
    queeryVector = torch.zeros(index.size, totalNumberBP * N_channels + 1, device=device)
    i = 0
    for iStep in index:
        temp = LBP_extractor(EEG[:, iStep:iStep + half], totalNumberBP, label, T, device)
        queeryVector[i, :] = temp.view(-1)   # PORT: (n,1) -> (n,)
        i = i + 1
    return queeryVector


def LBP_extractor(EEG, totalNumberBP, label, T, device=None):
    ''' starting from EEG data, it creates the histogram of LBP for the target segment.
    Return: Features_vector: in position 0 the label, then the full histogram (features).
    '''
    device = device or EEG.device
    N_channels, learningEnd = EEG.size()
    Features_vector = torch.zeros(totalNumberBP * N_channels + 1, 1, device=device)
    LBP_weights = torch.tensor([2**0, 2**1, 2**2, 2**3, 2**4, 2**5], dtype=torch.float32, device=device)
    chan_offset = torch.arange(N_channels, device=device, dtype=torch.float32) * totalNumberBP
    for iStep in range(learningEnd - 6):
        x = EEG[:, iStep:(iStep + T)].float()
        bp = ((x[:, 1:T] - x[:, 0:T - 1]) > 0).float()
        value = torch.sum(torch.mul(LBP_weights, bp), dim=1) + 1
        index = chan_offset + value
        Features_vector[index.long()] = Features_vector[index.long()] + 1
    Features_vector[0] = label
    return Features_vector


def LGP_window_train(EEG, fs, totalNumberBP, label, T, device=None):
    ''' Same as LBP_window_train but with local gradient patterns (LGP). '''
    device = device or EEG.device
    N_channels, learningEnd = EEG.size()
    half = fs // 2
    index = np.arange(0, learningEnd, half)
    queeryVector = torch.zeros(index.size, totalNumberBP * N_channels + 1, device=device)
    i = 0
    for iStep in index:
        temp = LGP_extractor(EEG[:, iStep:iStep + half], totalNumberBP, label, T, device)
        queeryVector[i, :] = temp.view(-1)
        i = i + 1
    return queeryVector


def LGP_extractor(EEG, totalNumberGP, label, T, device=None):
    ''' starting from EEG data, it creates the histogram of LGP for the target segment. '''
    device = device or EEG.device
    N_channels, learningEnd = EEG.size()
    Features_vector = torch.zeros(totalNumberGP * N_channels + 1, 1, device=device)
    LBP_weights = torch.tensor([2**0, 2**1, 2**2, 2**3, 2**4, 2**5], dtype=torch.float32, device=device)
    chan_offset = torch.arange(N_channels, device=device, dtype=torch.float32) * totalNumberGP
    c = (T - 1) // 2                         # PORT: (T-1)/2 -> (T-1)//2
    neigh = [0, 1, 2, 4, 5, 6]
    for iStep in range(4, learningEnd - 4):
        x = EEG[:, iStep - c:iStep + c + 1].float()
        x = torch.abs(x - x[:, c:c + 1])                                   # |x - centre sample|
        bp = ((x - torch.mean(x[:, neigh], 1, keepdim=True)) > 0).float()  # vs mean of neighbours
        value = torch.sum(torch.mul(LBP_weights, bp[:, neigh]), dim=1) + 1
        index = chan_offset + value
        Features_vector[index.long()] = Features_vector[index.long()] + 1
    Features_vector[0] = label
    return Features_vector
