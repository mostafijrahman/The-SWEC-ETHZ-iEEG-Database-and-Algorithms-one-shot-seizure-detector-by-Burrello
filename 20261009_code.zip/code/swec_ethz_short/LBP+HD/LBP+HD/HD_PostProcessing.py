"""
HD_PostProcessing.py - Python 3 / PyTorch 2 port (Burrello et al., BioCAS 2018)

Applies the moving average (10 half-second windows) and the patient threshold to the
predictions written by iEEGClassifierLBP+HD.py, and prints specificity, sensitivity
and mean detection delay. Also appends one row per patient to
results\\swec_short\\LBP+HD\\summary.csv.

Run with the SAME settings as the classifier:
    $env:SWEC_PATIENT = 6
    python HD_PostProcessing.py

Changes vs. the original are marked "PORT:".
"""
import csv
import os
from datetime import datetime

import torch
import numpy

import swec_config as cfg   # PORT: shared paths/tables/device

# we can run the postProcessing for 1 Patient at the time.
dim = 5
Threshold_size = 10
fs = cfg.FS
device = cfg.get_device()             # PORT: was torch.cuda.set_device(1)
seizureN = cfg.seizureN               # number of seizures of each patient
seizureTrain = cfg.Seizure_train      # number of seizures used for training
threshold = cfg.threshold             # threshold of postprocessing
win_dim = int(numpy.ceil(fs * dim / 10))   # PORT: numpy.int was removed from NumPy
PatientList = cfg.patients_from_env(default=[2])   # PORT: was a commented list with only 14 active

summary_csv = cfg.RESULTS_DIR / "summary.csv"

for Patient in PatientList:
    K = cfg.folds(Patient)            # PORT: same folds as the classifier (see swec_config.py)
    number_seizures = list(range(seizureN[Patient-1]))
    cross = list(range(K))
    counter1 = 0
    l = 0
    delay = 0
    print(f'=== Patient {Patient}: {seizureN[Patient-1]} seizures, {K} fold(s), threshold {threshold[Patient-1]} ===')
    for j in cross:
        for i in number_seizures:
            # loading each file created with the test of a single seizure using each other seizure to train
            # Example with 2 seizure: we will have for example 2 different files for seizure 1, one trained with seizure 1, one with seizure 2
            # PORT: path/name unified with the classifier (see cfg.prediction_file)
            prediction = torch.load(cfg.prediction_file(Patient, i + 1, j), map_location=device)
            Pred_mean = torch.zeros(prediction.size()[0], device=device)
            # Threhsolding the results inside the big 5 second window
            for k in numpy.arange(Threshold_size, prediction.size()[0]):
                Pred_mean[k] = torch.mean(prediction[k-Threshold_size:k])
            Pred_mean = torch.add(Pred_mean, threshold[Patient-1])
            Final_prediction = torch.sign(Pred_mean)
            First = 1
            counter = 0
            # updating of the delay and seizure detection (yes or not) for that particular recording
            for k in numpy.arange(0, Final_prediction.size()[0]):
                if Final_prediction[k] == 1 and First == 1 and k > 170*10/dim:
                    print(k/(10/float(dim)))
                    l = l + 1
                    delay = k/(10/float(dim)) - 180 + delay
                    First = 0
                elif Final_prediction[k] == 1 and k < 170*10/dim:
                    counter = counter + 1
            counter1 = counter1 + counter
            print('number of false:' + str(counter))
        print('end fold')
    # statistics computation and printing
    stamp = (1 - counter1/float(170*10/dim*seizureN[Patient-1]*K))*100
    stamp2 = (l) / float(seizureN[Patient-1]*K)*100
    print('Specificity =' + str(stamp))
    print('Sensitivity =' + str(stamp2))
    print('-----')
    # raw delay estimation, considering also the seizures used for train
    delay = delay/l if l else float('nan')   # PORT: avoid division by zero when nothing is detected
    print('Mean delay: ' + str(delay))

    # PORT: keep a machine-readable record for the replication table
    summary_csv.parent.mkdir(parents=True, exist_ok=True)
    new = not summary_csv.exists()
    with open(summary_csv, "a", newline="") as fh:
        w = csv.writer(fh)
        if new:
            w.writerow(["timestamp", "patient", "data_folder", "folds", "fold_mode", "seed",
                        "original_train_index", "threshold", "specificity", "sensitivity", "mean_delay_s"])
        w.writerow([datetime.now().isoformat(timespec="seconds"), Patient, cfg.data_folder(Patient).name, K,
                    os.environ.get("SWEC_FOLDS", "full"), cfg.seed(),
                    os.environ.get("SWEC_ORIGINAL_TRAIN_INDEX", "0"), threshold[Patient-1],
                    round(stamp, 2), round(stamp2, 2), round(delay, 2)])
    print(f'Row appended to {summary_csv}')
